import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class StartCss {
    WebDriver wd;

    @Test
    public class HW1 {
        public void passwordCss() {
            wd = new ChromeDriver();
            wd.get("https://contacts-app.tobbymarshall815.vercel.app/home");
            WebElement loginTab1 = wd.findElement(By.cssSelector("[href='/login']"));
            loginTab.click();

            WebElement emailTextBox1 = wd.findElement(By.cssSelector("[placeholder='Email']"));
            emailTextBox.click();
            emailTextBox.clear();
            emailTextBox.sendKeys("Felicita92@mail.com");

            WebElement password1 = wd.findElement(By.cssSelector("[placeholder='Password']"));
            password.click();
            password.clear();
            password.sendKeys("FElicita92");

            WebElement registrationButton = wd.findElement(By.cssSelector("[div.login_login__3EHKB:last-child]"));
            loginTab.click();

            List<WebElement> list1 = wd.findElements(By.cssSelector("button"));
            WebElement registrationButton1 = list.get (1);

            wd.findElement(By.cssSelector("root"));
            wd.findElement(By.xpath("//*[@id='root'"));

            wd.findElement(By.cssSelector("container"));
            wd.findElement(By.xpath("//*[@class='container']"));

            wd.findElement(By.cssSelector("[href='/home']"));
            wd.findElement(By.xpath("//*[@href='/home'"));

            //detailed
            wd.findElement(By.cssSelector("//*[@placeholder='Password']"));
            //starts
            wd.findElement(By.cssSelector("//*[@placeholder ^='Pass']"));
            //ends
            wd.findElement(By.cssSelector("//*[@placeholder $='word']"));
            //middle
            wd.findElement(By.cssSelector("//*[@placeholder @='swo']"));
            //contains

            wd.findElement(By.cssSelector("//*[contains(@placeholder,'as')]"));
            wd.findElement(By.cssSelector("//*[starts-with(@placeholder,'Em')]"));

            ////*[text()='SOKOLOV']
            ////div[@class='login_login__3EHKB']/.. parents
            ////br/ancestor-or-self::] parents and me
            ////input[1]/following-sibling::* me and down on the same branches
            ////button[2]/preceding-sibling::input[2] me and up on the same branches
        }
    }
